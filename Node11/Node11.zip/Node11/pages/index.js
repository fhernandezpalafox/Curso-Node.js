function  alerta()
{
	alert("hola desde un boton");
}